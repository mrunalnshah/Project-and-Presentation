#include <stdio.h>
#include <string.h>

void busbooking(int notadmin);

void busbooking(int notadmin){
    system("cls");
    printf("*****************************************************************************\n");
    printf("                          PANDA BOOKING                                      \n");
    printf("*****************************************************************************\n");

    FILE *busdetails, *busread,*bustotalseats;
    int choicebusnumber;
    int initial = 0;
    int temp_num_busdetails;
    char temp_line_busdetails_num[500];
    char temp_line_busdetails_name[500];
    char filecat[100] = "bus";
    char char_bus_number[100];
    int busnumberarray[20];
    char busnamearray[20][60];
    int totalseats = 20;
    int seatstobook;
    int seatnumber;
    char seatname[500];
    char char_seat_number[200];
    char choice_busavailability;

    busdetails = fopen("busdetails.txt","r");

    if(busdetails == NULL){
        printf("\nDETAILS OF THE BUSES NOT FOUND KINDLY CHECK THE DATABASE!!!!\n");
        fclose(busdetails);
    }else{
        while(fscanf(busdetails,"%s %s",temp_line_busdetails_num,temp_line_busdetails_name) == 2){
            temp_num_busdetails = atoi(temp_line_busdetails_num);
            busnumberarray[initial] = temp_num_busdetails;
            strcpy(busnamearray[initial],temp_line_busdetails_name);
            initial++;
        }
        printf("\nDo you wish to retrieve the bus schedule list(Y/N) : ");
        scanf("%s",&choice_busavailability);
        if(choice_busavailability == 'y' || choice_busavailability == 'Y'){
            busavailability();
        }

        printf("\nEnter Bus Number : ");
        scanf("%d",&choicebusnumber);

        for(int i = 0; i < initial;i++){
            if(choicebusnumber == busnumberarray[i]){
                itoa(choicebusnumber,char_bus_number,10);
                strcat(char_bus_number,".txt");
                strcat(filecat,char_bus_number);
                strcat(filecat,".txt");
                busread = fopen(filecat,"r");
                if(busread == NULL){
                    busread = fopen(filecat,"w");
                    printf("\n");
                    busstatus(choicebusnumber,0);
                    printf("Enter Number of seats to book : ");
                    scanf("%d",&seatstobook);

                    bustotalseats = fopen(char_bus_number,"w");

                    if(seatstobook > totalseats){
                        printf("ONLY %d SEATS ARE AVAILABLE, WE CANNOT BOOK %d",totalseats,seatstobook);
                    }else{
                        for(int i = 0; i < seatstobook;i++){
                            printf("BOOKING [%d]\n",i+1);
                            printf("SEAT NUMBER       :  ");
                            scanf("%d",&seatnumber);
                            printf("NAME OF PASSANGER :  ");
                            scanf("%s",seatname);

                            itoa(seatnumber,char_seat_number,10);
                            totalseats = totalseats - 1;
                            fprintf(busread,"%s %s\n",char_seat_number,seatname);
                        }
                        fprintf(bustotalseats,"%d",totalseats);
                    }
                    fclose(busread);
                    fclose(bustotalseats);
                    fclose(busdetails);

                }else{
                    bustotalseats = fopen(char_bus_number,"r");
                    busread = fopen(filecat,"r");

                    fscanf(bustotalseats,"%d",&totalseats);
                    busstatus(choicebusnumber,0);

                    int initial_passengerdetails = 0;
                    char temp_line_passengerdetails_seatnumber[500];
                    char temp_line_passengerdetails_seatname[500];
                    int temp_num_seat;
                    int passengerdetails_seatnumber[20] = {NULL};
                    char passengerdetails_seatname[20][100] = {NULL};
                    while(fscanf(busread,"%s %s",temp_line_passengerdetails_seatnumber,temp_line_passengerdetails_seatname) == 2){
                        temp_num_seat = atoi(temp_line_passengerdetails_seatnumber);
                        passengerdetails_seatnumber[temp_num_seat] = temp_num_seat;
                        strcpy(passengerdetails_seatname[temp_num_seat],temp_line_passengerdetails_seatname);
                        initial++;
                    }
                    printf("Enter number of seats to book : ");
                    scanf("%d",&seatstobook);

                    if(seatstobook > totalseats){
                        printf("ONLY %d SEATS ARE AVAILABLE, WE CANNOT BOOK %d",totalseats,seatstobook);
                    }else{
                        for(int i = 0;i < seatstobook;i++){
                            printf("BOOKING [%d]\n",i+1);
                            printf("SEAT NUMBER       :  ");
                            scanf("%d",&seatnumber);
                            printf("NAME OF PASSANGER :  ");
                            scanf("%s",seatname);

                            passengerdetails_seatnumber[seatnumber] = seatnumber;
                            strcpy(passengerdetails_seatname[seatnumber],seatname);
                            totalseats = totalseats - 1;
                        }
                        bustotalseats = fopen(char_bus_number,"w");
                        busread = fopen(filecat,"w");
                        for(int i = 0;i < 20;i++){
                            if(passengerdetails_seatname[i] != NULL && passengerdetails_seatnumber[i] != NULL){
                                itoa(passengerdetails_seatnumber[i],char_seat_number,10);
                                fprintf(busread,"%s %s\n",char_seat_number,passengerdetails_seatname[i]);
                            }
                        }
                    }
                    fprintf(bustotalseats,"%d",totalseats);
                    fclose(busread);
                    fclose(bustotalseats);
                    fclose(busdetails);
                }
                system("cls");
                printf("\n\nTOTAL COST FOR BOOKING %d SEATS IS %d\n",seatstobook,seatstobook*1000);
                busstatus(choicebusnumber,0);
                printf("\nTHANKS FOR BOOKING WITH PANDAS\n");
                printf("\n\nPRESS ANY KEY TO CONTINUE...");
                getch();
                if(notadmin == 1){
                    admin();
                }else{
                    choice();
                }
            }
        }
       printf("\nBUS HAS NOT BE SCHEDULED YET!!!\n");
       fclose(busdetails);

    }

    printf("\n\nPRESS ANY KEY TO CONTINUE...");
    getch();
    if(notadmin == 1){
        admin();
    }else{
        choice();
    }
}
