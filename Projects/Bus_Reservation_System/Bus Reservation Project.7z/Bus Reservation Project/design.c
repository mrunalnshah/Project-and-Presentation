#include <stdio.h>
#include <stdlib.h>

void welcome();
void exit();
void returnpage();
void creator_details();
void user_welcome();
void admin_welcome();


void returnpage(){
    system("cls");
    printf("*****************************************************************************\n");
    printf("*                   PANDA TRANSPORTATION                                    *\n");
    printf("*****************************************************************************\n");

}
void welcome(){
    system("cls");
    printf("************************************************************************************************\n");
    printf("*                                                                                              *\n");
    printf("*                                                                                              *\n");
    printf("*                               Welcome to Panda transportation                                *\n");
    printf("*                                                                                              *\n");
    printf("*                                                                                              *\n");
    printf("************************************************************************************************\n");
    printf("\n\nEnter to continue....");
    getch();
    system("cls");
}

void goodbye(){
    system("cls");
    printf("************************************************************************************************\n");
    printf("*                                                                                              *\n");
    printf("*                                                                                              *\n");
    printf("*                               THANKS FOR USING PANDA TRANSPORTATION                          *\n");
    printf("*                                                                                              *\n");
    printf("*                                                                                              *\n");
    printf("************************************************************************************************\n");

    printf("\n\n\nEnter any key to exit the system!!!");
    getch();
    system("cls");
}

void creator_details(){
    printf("\n\n\n\t\t*********************************************************\n");
    printf("\t\t*              MADE BY DATARI ASGAR                     *\n");
    printf("\t\t*                      QURESHI AAQUIF                   *\n");
    printf("\t\t*                      SHAH MALAV                       *\n");
    printf("\t\t*                      MRUNAL SHAH                      *\n");
//    printf("\t\t*       \"https://www.linkedin.com/in/mrunalnshah/\"      *\n");
//    printf("\t\t*       \"https://github.com/mrunalnshah\"                *\n");
    printf("\t\t*********************************************************\n\n");

    printf("\n\n\nEnter any key to continue...");
    getch();
    system("cls");
}

void user_welcome(){
    system("cls");
    printf("\n\n\n\n\n\n\n\n\n\n\t\t\t*****************************************************************************\n");
    printf("\t\t\t                            WELCOME USER                                     \n");
    printf("\t\t\t*****************************************************************************\n");

}
void admin_welcome(){
    system("cls");
    printf("\n\n\n\n\n\n\n\n\n\n\t\t\t*****************************************************************************\n");
    printf("\t\t\t                            WELCOME ADMINISTRATOR                            \n");
    printf("\t\t\t*****************************************************************************\n");
}

