#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>

void admin();

void admin(){
    system("cls");
    returnpage();
    static int userchoice;
    printf("\t\t\t[1] View Bus List\n");
    printf("\t\t\t[2] Book Tickets\n");
    printf("\t\t\t[3] Cancel booking\n");
    printf("\t\t\t[4] Bus Status and Boarding\n");
    printf("\t\t\t[5] Register New Bus\n");
    printf("\t\t\t[6] Register New User\n");
    printf("\t\t\t[7] Exit [UNDER-DEVELOPMENT]\n");

    printf("\n\n\n\t\tEnter Your Choice --->  ");
    scanf("%d",&userchoice);

    switch(userchoice){
        case 1:
        {
            busavailability();
            printf("\n\nEnter to continue....");
            getch();
            system("cls");
            admin();
            break;
        }
        case 2:
        {
            busbooking(1);
            break;
        }
        case 3:
        {
            buscancellation(1);
            printf("\n\nEnter to continue....");
            getch();
            admin();
        }
        case 4:
        {
            returnpage();
            int buschoice;
            int choicebusavailability;

            printf("\nDo you wish to retrieve bus availability Info (Y/N) :  ");
            scanf("%s",&choicebusavailability);
            if(choicebusavailability == 'Y' || choicebusavailability == 'y'){
                busavailability();
            }

            printf("\n\nEnter Bus Number :  ");
            scanf("%d",&buschoice);
            busstatus(buschoice);
            printf("\n\nEnter to continue....");
            getch();
            admin();
        }
        case 5:
        {
            FILE *busdetails;
            int numberofbuses;
            int busnumber;
            char busroute[500];
            char temp_busnumber[500];
            int initial = 0;

            busdetails = fopen("busdetails.txt","r");

            if(busdetails == NULL){
                busdetails = fopen("busdetails.txt","w");

                printf("Enter number of buses to be register : ");
                scanf("%d",&numberofbuses);

                for(int i = 0;i < numberofbuses;i++){
                    printf("ENTER BUS [%d]\n",i+1);
                    printf("BUS NUMBER : ");
                    scanf("%d",&busnumber);
                    printf("\nROUTE NAME : ");
                    scanf("%s",busroute);

                    itoa(busnumber,temp_busnumber,10);

                    fprintf(busdetails,"%s %s\n",temp_busnumber,busroute);
                }
                fclose(busdetails);
            }else{
                busdetails = fopen("busdetails.txt","a");
                printf("Enter number of buses to be registered : ");
                scanf("%d",&numberofbuses);

                for(int i = 0; i < numberofbuses;i++){
                    printf("ENTER BUS [%d]\n",i+1);
                    printf("BUS NUMBER : ");
                    scanf("%d",&busnumber);
                    printf("\nROUTE NAME : ");
                    scanf("%s",busroute);

                    itoa(busnumber,temp_busnumber,10);
                    fprintf(busdetails,"%s %s\n",temp_busnumber,busroute);
                }
                fclose(busdetails);
            }
            admin();
        }
        case 6:
        {
            FILE *userdetails;
            int number_of_usernames_created;
            char temp_username[500], temp_password[500];
            char username_array[100][500], password_array[100][500];
            static int initial = 0;

            userdetails = fopen("userdetails.txt","r");

            if(userdetails == NULL){
                userdetails = fopen("userdetails.txt","w");

                printf("Enter number of username logins to be created ? ");
                scanf("%d",&number_of_usernames_created);

                for(int i = 0; i < number_of_usernames_created;i++){
                    printf("CREATING USERNAME [%d]\n",i+1);
                    printf("USERNAME : ");
                    scanf("%s",temp_username);
                    printf("PASSWORD : ");
                    scanf("%s",temp_password);

                    fprintf(userdetails,"%s %s\n",temp_username,temp_password);
                }
                fclose(userdetails);
            }else{
                while(fscanf(userdetails,"%s %s",temp_username,temp_password) == 2){
                    strcpy(username_array[initial],temp_username);
                    strcpy(password_array[initial],temp_password);
                    initial++;
                }
                printf("Enter number of username to be created ? ");
                scanf("%d",&number_of_usernames_created);
                initial++;

                for(int i = 0; i < number_of_usernames_created;i++){
                    printf("CREATING USERNAME [%d]\n",i+1);
                    printf("USERNAME : ");
                    scanf("%s",temp_username);
                    printf("PASSWORD : ");
                    scanf("%s",temp_password);

                    strcpy(username_array[initial],temp_username);
                    strcpy(password_array[initial],temp_password);
                    initial++;
                }
                fclose(userdetails);
                userdetails = fopen("userdetails.txt","w");
                for(int i = 0;i <= initial;i++){
                    fprintf(userdetails,"%s %s\n",username_array[i],password_array[i]);
                }
                fclose(userdetails);
            }
            printf("ADMIN PLEASE PRESS ANY KEY TO CONTINUE...");
            getch();
            admin();
        }
        case 7:
        {
            char crosscheck;
            printf("\nDo you wish to exit the system ? (Y/N) :  ");
            scanf("%s",&crosscheck);

            if(crosscheck == 'Y' || crosscheck == 'y'){
                goodbye();
                break;
            }else{
                system("cls");
                admin();
            }
            break;
        }
        default:
        {
           // goodbye();
            break;
        }
    }
}
