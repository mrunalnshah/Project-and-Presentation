void choice();

void choice(){
    system("cls");
    returnpage();
    int userchoice;
    printf("\t\t\t[1] View Bus List\n");
    printf("\t\t\t[2] Book Tickets\n");
    printf("\t\t\t[3] Cancel booking\n");
    printf("\t\t\t[4] Bus Status and Boarding\n");
    printf("\t\t\t[5] Exit [UNDER-DEVELOPMENT]\n");

    printf("\n\n\n\t\tEnter Your Choice --->  ");
    scanf("%d",&userchoice);

    switch(userchoice){
        case 1:
        {
            busavailability();
            printf("\n\nEnter to continue....");
            getch();
            system("cls");
            choice();
            break;
        }
        case 2:
        {
            busbooking(0);
            break;
        }
        case 3:
        {
            buscancellation(0);
            printf("\n\nEnter to continue....");
            getch();
            choice();
            break;
        }
        case 4:
        {
            returnpage();
            int buschoice;
            int choicebusavailability;

            printf("\nDo you wish to retrieve bus availability Info (Y/N) :  ");
            scanf("%s",&choicebusavailability);
            if(choicebusavailability == 'Y' || choicebusavailability == 'y'){
                busavailability();
            }

            printf("\n\nEnter Bus Number :  ");
            scanf("%d",&buschoice);
            busstatus(buschoice);
            printf("\n\nEnter to continue....");
            getch();
            choice();
            break;
        }
        case 5:
        {
            char crosscheck;
            printf("\nDo you wish to exit the system ? (Y/N) :  ");
            scanf("%s",&crosscheck);

            if(crosscheck == 'Y' || crosscheck == 'y' || crosscheck == "y" || crosscheck == "Y"){
                goodbye();
                break;
            }else{
                system("cls");
                choice();
                break;
            }
            break;
        }
        default:
        {
            goodbye();
        }
    }
}
