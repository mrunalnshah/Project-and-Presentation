#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void busstatus(int busnumber,int notchoice);

void busstatus(int busnumber,int notchoice){
    FILE *busdetails, *busread,*bustotalseats;

    char passengerdetails_seatname[20][100] = {"EMPTY","EMPTY","EMPTY","EMPTY","EMPTY","EMPTY","EMPTY","EMPTY","EMPTY","EMPTY","EMPTY","EMPTY","EMPTY","EMPTY","EMPTY","EMPTY","EMPTY","EMPTY","EMPTY","EMPTY"};

    int initial = 0;
    int temp_num_busdetails;
    char temp_line_busdetails_num[500];
    char temp_line_busdetails_name[500];
    char filecat[100] = "bus";
    char char_bus_number[100];
    int busnumberarray[20];
    char busnamearray[20][60];
    int totalseats = 20;
    int seattocancel;
    int seatnumber;
    char seatname[500];
    char char_seat_number[200];
    int initial_passengerdetails = 0;
    char temp_line_passengerdetails_seatnumber[500];
    char temp_line_passengerdetails_seatname[500];
    int temp_num_seat;
    int passengerdetails_seatnumber[20] = {NULL};

    busdetails = fopen("busdetails.txt","r");

    if(busdetails == NULL){
        printf("DETAILS OF THE BUSES NOT FOUND KINDLY CHECK THE DATABASE!!!!\n");
    }else{
        while(fscanf(busdetails,"%s %s",temp_line_busdetails_num,temp_line_busdetails_name) == 2){
            temp_num_busdetails = atoi(temp_line_busdetails_num);
            busnumberarray[initial] = temp_num_busdetails;
            strcpy(busnamearray[initial],temp_line_busdetails_name);
            initial++;
        }
        for(int i = 0; i < initial;i++){
            if(busnumber == busnumberarray[i]){
                itoa(busnumber,char_bus_number,10);
                strcat(char_bus_number,".txt");
                strcat(filecat,char_bus_number);
                strcat(filecat,".txt");
                busread = fopen(filecat,"r");
                if(busread == NULL){
                    printf("NO BUS FOUND!!!\n");
                    fclose(busread);
                    fclose(busdetails);
                }else{
                    bustotalseats = fopen(char_bus_number,"r");
                    busread = fopen(filecat,"r");

                    fscanf(bustotalseats,"%d",&totalseats);


                    while(fscanf(busread,"%s %s",temp_line_passengerdetails_seatnumber,temp_line_passengerdetails_seatname) == 2){
                        temp_num_seat = atoi(temp_line_passengerdetails_seatnumber);
                        passengerdetails_seatnumber[temp_num_seat] = temp_num_seat;
                        strcpy(passengerdetails_seatname[temp_num_seat-1],temp_line_passengerdetails_seatname);
                        initial++;
                    }
                        printf("*********************************************\n");
                        printf("                BUS STATUS                   \n");
                        printf("*********************************************\n");
                    for(int i = 0;i < 20;i = i + 2){
                            printf("[%2d] %9s\t\t[%2d] %9s\n",i+1,passengerdetails_seatname[i],i+2,passengerdetails_seatname[i+1]);
                    }
                }
                fclose(busread);
                fclose(bustotalseats);
                fclose(busdetails);

                if(notchoice == 1){
                    printf("*********************************************\n");
                    printf("TOTAL SEATS AVAILABLE ARE %d\n",totalseats);
                    printf("*********************************************\n");
                    printf("\n\nPRESS ANY KEY TO CONTINUE...");
                    getch();
                    choice();
                }else{
                    printf("*********************************************\n");
                    printf("TOTAL SEATS AVAILABLE ARE %d\n",totalseats);
                    printf("*********************************************\n");
                }
            }
        }
    }
}
