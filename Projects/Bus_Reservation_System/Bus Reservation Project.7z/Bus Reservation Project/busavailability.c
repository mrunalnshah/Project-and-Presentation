#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void busavailability();

void busavailability(){
    char line1[500], line2[500];
    int busnumberarray[20];
    char busnamearray[20][60];
    int temp_num;
    int initial = 0;

    FILE *busdetails;

    busdetails = fopen("busdetails.txt","r");

    while(fscanf(busdetails,"%s %s",line1,line2) == 2){
        temp_num = atoi(line1);
        busnumberarray[initial] = temp_num;
        strcpy(busnamearray[initial],line2);
        initial++;
    }

    printf("*********************************************\n");
    printf(" BUS NUMBER             BUS ROUTE            \n");
    printf("*********************************************\n");
    for(int i = 0; i < initial; i++){
        printf(" %d\t\t\t%s\n",busnumberarray[i],busnamearray[i]);
    }
}
