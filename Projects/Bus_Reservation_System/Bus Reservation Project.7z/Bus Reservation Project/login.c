#include <stdio.h>
#include <string.h>
#include <conio.h>

#define ENTER 13
#define TAB 9
#define BACKSPACE 8
#define SPACE 32

static int attempt = 0;

int login();

int login(){
    printf("*****************************************\n");
    printf("*                LOGIN                  *\n");
    printf("*****************************************\n\n\n");

    printf("*****************************************\n");

    FILE *userdetails;
    char enterusername[12],enterpassword[12];
    char username[100][200], password[100][200];
    char adminUsername[] = "admin";
    char adminPassword[] = "admin";
    int i = 0;
    char ch;
    char temp_username[500], temp_password[500];
    int initial_login = 0;
    char yesorno;

    userdetails = fopen("userdetails.txt","r");
    if(userdetails == NULL){
        printf("CURRENTLY THERE IS NO USER REGISTERED TO USE THE SYSTEM ASK ADMIN TO CREATE USERNAMES...\n\n\n");
    }else{
        while(fscanf(userdetails,"%s %s",temp_username,temp_password) == 2){
            strcpy(username[initial_login],temp_username);
            strcpy(password[initial_login],temp_password);
            initial_login++;
        }
    }
    printf("Enter Username : ");
    scanf("%s",enterusername);
    printf("\nEnter Password  :  ");
    while(1){
        ch = getch();
        if(ch == ENTER){
            enterpassword[i] = '\0';
            break;
        }else if(ch == BACKSPACE){
            if(i > 0){
                i--;
                printf("\b \b");
            }
        }else if(ch == TAB || ch == SPACE){
            continue;
        }else{
            enterpassword[i] = ch;
            i++;
            printf("*");
        }
    }

    if(strcmp(enterusername,adminUsername) == 0 && strcmp(enterpassword,adminPassword) == 0){
        return 2;
    }
    for(int i = 0; i <= initial_login;i++){
        if((strcmp(enterusername,username[i]) == 0) && (strcmp(enterpassword,password[i]) == 0)){
                return 1;
        }
    }
    if(attempt == 3){
        printf("\n 530 Login Authentication Failed!!!\n\n");
        printf("Press any key to continue...\n");
        getch();
        return 0;
    }
    printf("\n*************************************\n");
    printf("Do you want to retry (Y/N) ?  ");
    scanf("%s",&yesorno);
    if(yesorno == 'y' || yesorno == 'Y'){
        system("cls");
        attempt++;
        login();
    }else{
        return 0;
    }
}
