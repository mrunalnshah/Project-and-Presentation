#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(){
    welcome();
    creator_details();
    int login_result;

    login_result = login();

    if(login_result == 1){
        user_welcome();
        printf("\t\t\tPRESS ANY KEY TO ENTER THE USER INTERFACE...\n");
        getch();
        choice();
    }else if(login_result == 2){
        admin_welcome();
        printf("\t\t\tPRESS ANY KEY TO ENTER THE ADMIN SPACE...\n");
        getch();
        admin();
    }else if(login_result == 0){
        goodbye();
        creator_details();
    }
    else{
        goodbye();
        creator_details();
    }
    return 0;
}
